package se.kth.sda.queuenum.model;

/**
 * Manages and stores queue number.
 */
public class QueueNumber {
    private int queueNo = 0;
}
